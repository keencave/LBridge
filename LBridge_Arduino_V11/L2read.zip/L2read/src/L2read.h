/*
 * L2read.h
 */

// ensure this library description is only included once
#ifndef L2readr_h
#define L2read_h

//unsigned char CustomReadSingleBlockReturn(unsigned char addrLo, unsigned char addrHi);

int precompTestFunc(void);

#endif

